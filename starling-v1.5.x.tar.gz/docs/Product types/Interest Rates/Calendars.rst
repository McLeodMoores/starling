Use the ISDA_HOLIDAY scheme and the ISDA business center 4 letter code (2 letter
country code followed by 2 letter city code) e.g.

* USNY
* GBLO
* EUTA.

For the full list of acceptable values see the `ISDA business center specification`_.

.. _ISDA business center specification: http://www.fpml.org/coding-scheme/business-center