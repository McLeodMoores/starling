The `FpML business day convention schema`_ is used.

* NONE
* FOLLOWING
* MODFOLLOWING
* PRECEDING
* MODPRECEDING

.. _FpML business day convention schema: http://www.fpml.org/spec/fpml-5-4-6-rec-2/html/confirmation/schemaDocumentation/schemas/fpml-ird-5-4_xsd/complexTypes/FinalCalculationPeriodDateAdjustment/businessDayConvention.html