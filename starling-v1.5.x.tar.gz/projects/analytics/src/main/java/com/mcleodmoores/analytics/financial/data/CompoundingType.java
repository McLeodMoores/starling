/**
 * Copyright (C) 2017 - present McLeod Moores Software Limited.  All rights reserved.
 */
package com.mcleodmoores.analytics.financial.data;

/**
 *
 */
public enum CompoundingType {

  SIMPLE,
  ANNUAL,
}
